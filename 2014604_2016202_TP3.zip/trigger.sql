SET search_path = vetoDb;


CREATE TABLE if not exists VetoDb.Historique (
    noTraitement VARCHAR(10) not NULL,
	noExamen VARCHAR(10) not NULL,
	noVeterinaire VARCHAR(10) not NULL, 
	noAnimal VARCHAR(10) not NULL
   
   
   	

);

DROP  FUNCTION IF EXISTS save_animal() CASCADE ;


Create FUNCTION save_animal() returns trigger as $save_animal$
Begin

	Insert into VetoDb.Historique
	Select (traitement.noTraitement) ,( traitement.noExamen) ,(examen.noVeterinaire),(examen.noAnimal) 
	from VetoDB.traitementeffectue traitement,VetoDb.examen examen
	Where traitement.noExamen = examen.noExamen and
	examen.noAnimal = old.noAnimal
	--Ce trigger fonctionne pour le noVeterinaire 1 parce que ca dit pour un vétérinaire donné
	
	and examen.noVeterinaire='1';
	--
	
	return OLD;

End;
$save_animal$ 
Language plpgsql;


CREATE TRIGGER sauvegarde Before Delete ON VetoDb.Animal
FOR EACH ROW EXECUTE FUNCTION save_animal();







