export interface TraitementEffectue {

noexamen:string;
noclinique:string;
notraitement:string;
quantitetraitement:string;
datedebut:Date;
datefin:Date;
description:string;
cout:number;

}