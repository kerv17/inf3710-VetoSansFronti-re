export interface Clinique {
    noclinique: string;
    nom:number;
    rue:string;
    ville:string;
    province:string;
    codepostal:string
    numtelephone:string;
    numtelecopieur:string;
}