import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-proprietaire-animal',
  templateUrl: './proprietaire-animal.component.html',
  styleUrls: ['./proprietaire-animal.component.css']
})
export class ProprietaireAnimalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
