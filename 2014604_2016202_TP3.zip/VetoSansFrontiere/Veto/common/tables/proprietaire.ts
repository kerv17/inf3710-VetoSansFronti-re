export interface Proprietaire {
    noProprietaire: any;
    noClinque:string
    noproprietaire:string
    nom:string;
    prenom:string;

    addresse:string[];
    telephone:string;
}
